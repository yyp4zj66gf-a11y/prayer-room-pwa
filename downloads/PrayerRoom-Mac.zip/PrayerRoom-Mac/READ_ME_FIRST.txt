PRAYER ROOM (Mac) — READ ME FIRST

OPEN:
1) Unzip the file.
2) Drag “Prayer Room.app” into Applications.
3) First time: Right-click the app → Open → Open.

NAME:
- First run asks for your name.
- If you skip it, it uses “Friend”.
- You can change it later using the “Change Name” button.

HOW IT WORKS:
TOP: Daily Scripture (rotates daily; Prev/Next; Copy copies it)
LEFT: Daily Prayer List (permanent list of names; paste/type; Save List)
RIGHT: Prayers & Petitions (saved by date; Today button; Save Prayer)
BOTTOM: Salvation Army Doctrine (rotates daily; Prev/Next)

MIDNIGHT:
- Scripture + Doctrine + the date update at midnight.
- Your Daily Prayer List stays the same.
